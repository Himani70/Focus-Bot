# FocusBot

## Team Members

* Himani Jangam - hjangam
* Jagan Cherukuru Agribabu - jcheruk
* Prashanthi Kanniappan Murthy - pkannia
* Priyankha Bhalasubbramanian - pbhalas

## Link to Design document
[Design document](DESIGN.md)

## Link to BOT.md
[BOT.md](Milestone-1/BOT.md)

## Link to PROCESS.md
[PROCESS.md](Milestone-2/PROCESS.md)

## Link to DEPLOY.md
[DEPLOY.md](DEPLOY.md)

## Link to REPORT.md
[REPORT.md](REPORT.md)
